def first_turn_start(turn):
    global avalon_stack
    avalon_stack = 0
    print("Player:")
    print("Max_HP: " + str(max_hp))
    print("HP: " + str(hp))
    print("Max_MP: " + str(max_mp))
    print("MP: " + str(mp))
    print("Attack: " + str(phys_atk))
    print("Defense: " + str(phys_def))
    print("Magical Attack: " + str(magi_atk))
    print("Magical Defense: " +  str(magi_def))
    print("----------------------------------")
    print(enemy_name + ":")
    print("Max_HP: " + str(en_max_hp))
    print("HP: " + str(en_hp))
    print("Max_MP: " + str(en_max_mp))
    print("MP: " + str(en_mp))
    print("Attack: " + str(en_phys_atk))
    print("Defense: " + str(en_phys_def))
    print("Magical Attack: " + str(en_magi_atk))
    print("Magical Defense: " +  str(en_magi_def))
    if can_revive:
        print("Enemy Revies: " + str(max_en_revives))
    turn_start(turn)

def turn_start(turn):
    global en_defined_def
    global hp
    global en_defined_magi_def
    global mp
    global en_mp
    global halve_stacks
    global Recursive_Magic
    global damage
    global max_hp
    global max_mp
    global phys_atk
    global magi_atk
    global avalon_stack
    global hasAvalon
    global invincible
    global test_loop
    global defined_atk
    global defined_magi_atk
    global defined_def
    global defined_magi_def
    global hasExcalibur
    global excalibur_stacks
    global burned
    global self_turn
    invincible = False
    if hp <= 0:
        if invincible:
            hp = prehp
            burned = False
        else:
            print("Player has been defeated the battle and was lost")
            sys.exit("Thanks for playing!")
    if en_hp <= 0 and en_revives >= 1:
        enemy_revives(turn)
    elif en_hp <= 0:
        print("Player has finished the battle and won")
        sys.exit("Thanks for playing!")
    defined_def = phys_def
    defined_def  = defined_def * mult_def
    defined_def = defined_def / phys_def_break
    defined_magi_def = magi_def
    defined_magi_def = defined_magi_def * mult_def
    en_defined_magi_def = en_magi_def
    en_defined_def = en_phys_def
    defined_atk = phys_atk
    defined_magi_atk = magi_atk
    if hasExcalibur:
        defined_atk *= 6
        defined_magi_atk *= 6
    if avalon_stack == 4:
        print("After player searched they found the ultimate defense, Avalon")
        hasAvalon = True
        avalon_stack = 0
    if excalibur_stacks == 4:
        print("There was a lake, and drifting down the lake was the holy blade of destined victory. Excalibur")
        hasExcalibur = True
        excalibur_stacks = 0
    if berserker_defense_Half:
        en_defined_def = en_defined_def/halve_stacks
        en_defined_magi_def = en_defined_magi_def/halve_stacks
    turn = turn + 1
    if burned:
        print("----------------------------------")
        damage = (max_hp/9)
        print("Player took " + str(damage) + "burn damage")
        hp -= damage
    if enemy_mana_drain:
        damage = int(round(en_max_mp / 16, 0))
        if damage > en_mp:
            damage = en_mp
        print("Player drained " + str(damage) + " mana from " + str(enemy_name))
        en_mp -= damage
        mp += damage
    if mp > max_mp:
        overflow = mp - max_mp
        Recursive_Magic += overflow
        mp = max_mp
    while Recursive_Magic >= 100:
        test_loop += 1
        if max_hp < 1000.0:
            max_hp += 10
            hp += 10
            max_mp += 10
            mp += 10
            phys_atk += 15
            magi_atk += 15
        elif max_hp < 2000.0 and hasExcalibur:
            max_hp += 20
            hp += 20
            max_mp += 20
            mp += 20
            phys_atk += 10
            magi_atk += 10
        elif max_hp < 5000.0 and enemy_id == 6 and en_revives == 2:
            max_hp += 200
            hp += 200
            max_mp += 200
            mp += 200
            phys_atk += 100
            magi_atk +=100
        Recursive_Magic -= 100
        damage = 0
    test_loop = 0
    if hp > max_hp:
        hp = max_hp
    print("----------------------------------")
    print("player turn: " + str(turn))
    print("HP: " + str(hp) + "/" + str(max_hp))
    print("MP: " + str(mp) + "/" + str(max_mp))
    if stat_check:
        if not hasAvalon:
            print("Avalon Pity: " + str(Avalon_pity))
        else:
            if not hasExcalibur:
                print("Excalibur Pity: " + str(excalibur_pity))
        if self_turn > 0:
            print("Self Turns: " + str(self_turn))
    if avalon_stack > 0:
        print("???: " + str(avalon_stack) + "/4")
    if hasAvalon:
        print("Avalon: Active")
    if stat_check and hasAvalon:
        print("Avalon Multiplier: " + str(avalon_mult))
    if excalibur_stacks > 0:
        print("?!?!: " + str(excalibur_stacks) + "/4")
    if hasExcalibur:
        print("Excalibur: Obtained")
    rng = random.randrange(1,4)
    if paralysis and rng == 1:
        print("The player was Paralyzed")
        en_turn_start(turn)
    else:
        player_choice(turn)

def en_turn_start(turn):
    global hp
    global defined_def
    global defined_magi_def
    global enemy_id
    global en_burned
    global en_phys_atk
    global en_phys_def
    global en_magi_def
    global en_burned
    global en_hp
    global en_max_hp
    global en_revives
    global en_mp
    global en_max_mp
    global max_en_revives
    global invincible
    global prehp
    global avalon_mult
    global burned
    global player_turn
    global en_paralysis
    player_turn = False
    if hp > max_hp:
        hp = max_hp
    if hasAvalon:
        defined_def = defined_def * avalon_mult
        defined_magi_def = defined_magi_def * avalon_mult
    if en_burned:
        print("----------------------------------")
        damage = (en_max_hp/16)
        print(enemy_name + " took " + str(damage) + "burn damage")
        en_hp -= damage
    damage = 0
    if enemy_id == 3:
        print("Berserker healed their mana")
        en_mp += en_max_mp/8
    print("----------------------------------")
    print(enemy_name + "'s turn: ")
    print(enemy_name + "'s HP: " + str(en_hp) + "/" + str(en_max_hp))
    print(enemy_name + "'s MP: " + str(en_mp) + "/" + str(en_max_mp))
    if can_revive:
        print(enemy_name + "'s Revives: " + str(en_revives) + "/" + str(max_en_revives))
    prehp = hp
    if not en_paralysis:
        match enemy_id:
            case 1:
                goblin_ai(turn)
            case 2:
                mage_ai(turn)
            case 3:
                berserker_AI(turn)
            case 4:
                golem_ai(turn)
            case 5:
                angel_ai(turn)
            case 6:
                TDK_AI(turn)
            case _:
                goblin_ai(turn)
    else:
        print(enemy_name + " was paralyzed")
    avapitwait(turn)
    if hp <= 0:
        if invincible:
            hp = prehp
            burned = False
        else:
            print("Player has been defeated the battle and was lost")
            sys.exit("Thanks for playing!")
    elif invincible:
        hp = prehp
    if invincible:
        print("Player is invincible and didn't take any damage!")
        burned = False
    turn_start(turn)

def player_choice(turn):
    global damage
    global en_hp
    global enemy_name
    global hp
    global defined_def
    global mp
    global always_status
    global en_phys_atk
    global en_phys_def
    global en_magi_def
    global en_burned
    global en_hp
    global en_max_hp
    global en_revives
    global choice
    global mult_def
    global can_revive
    global avalon_stack
    global enemy_id
    global invincible
    global Recursive_Magic
    global hasAvalon
    global halfhp
    global player_turn
    player_turn = True
    choice = 0
    damage = 0
    halfhp = max_hp / 2
    print("Choices: ")
    print("1.Fight: ")
    print("2.Magic: ")
    print("3.Guard: ")
    print("4.Stats: ")
    try:
        choice = int(input("Choice your decision: "))
    except ValueError:
        choice = 0
    match choice:
        case 1:
            if not hasExcalibur:
                damage = calculate_physical_damage(defined_atk, en_defined_def)
            else:
                damage = calculate_physical_damage(((defined_atk) + (defined_magi_atk * 1.16)), en_defined_def)
            print(enemy_name + " took " + str(damage) + " damage!")
        case 2:
            magic_menu(turn)
        case 3:
            print("Player guarded")
            defined_def = defined_def * 2
        case 4:
            stats(turn)
        case 90:
           devtools(choice)
        case _:
            print("Choice a valid input")
            player_choice(turn)
    en_hp = en_hp - damage
    if en_hp <= 0 and en_revives >= 1:
        enemy_revives(turn)
    elif en_hp <= 0:
        print("Player has finished the battle and won")
        sys.exit("Thanks for playing!")
    en_turn_start(turn)

def magic_menu(turn):
    global mult_def
    global en_hp
    global damage
    global mp
    global hp
    global status_chance
    global en_burned
    global enemy_mana_drain
    global en_phys_atk
    global en_phys_def
    global en_magi_def
    global en_burned
    global en_hp
    global en_max_hp
    global en_revives
    global invincible
    damage = 0
    print("Magic:")
    print("----------------------------------")
    print("1.Fire 2MP")
    print("2.Holy Bless 4MP")
    print("3.Heal 6MP")
    print("4.Self Sacrifice 10HP")
    print("5.Mana Drain 8MP")
    print("6.Invincible All MP")
    print("N.Back")
    choice = input("Choice your decision: ").lower()
    print("----------------------------------")
    match choice:
        case '1':
            if mp >= 2:
                print("Player uses Fire")
                magic_power = 15
                if hasExcalibur:
                    magic_power *= 4
                damage = calculate_magical_damage(defined_magi_atk, en_defined_magi_def, magic_power)
                print(enemy_name + " took " + str(damage) + " damage!")
                status_chance = random.randrange(1,11)
                if status_chance == 1:
                    print("Player was burned")
                    en_burned = True
                mp -= 2
            else:
                print("Out of MP!")
                return player_choice(turn)
        case '2':
            if mp >= 4:
                print("Player used Holy Bless!")
                print("Their defense was multiplied")
                mult_def += 1.5
                if hasExcalibur:
                    mult_def += 1.5
                mp -= 4
            else:
                print("Out of MP!")
                return player_choice(turn)
        case '3':
            if mp >= 6:
                print("Player used Heal!")
                damage = (max_hp/5)*(magi_atk*.10)
                print("Player has healed " + str(damage) + " Damage")
                hp += damage
                mp -= 6
                damage = 0
            else:
                print("Out of MP!")
                return player_choice(turn)
        case '4':
            if hp >= 10:
                print("Player used Self Sacrifice!")
                print("Player swapped 10 HP for 10 MP")
                hp -= 10
                mp += 10
            else:
                print("Out of MP!")
                return player_choice(turn)
        case '5':
            if mp >= 8:
                print("Player used Mana Drain!")
                print("Player inflicted " + str(enemy_name) + " with a mana drain spell")
                enemy_mana_drain = True
                mp -= 8
            else:
                print("Out of MP!")
                return player_choice(turn)
        case '6':
            if mp >= 1:
                print("Player used Invincible!")
                print("Player used their mana to cover their body in invincible mana")
                invincible = True
                mp = 0
            else:
                print("Out of MP!")
                return player_choice(turn)
        case 'n':
            return player_choice(turn)
        case _:
            print("Invalid choice")
            return player_choice(turn)
    en_hp -= damage
    if en_hp <= 0 and en_revives >= 1:
        enemy_revives(turn)
    elif en_hp <= 0:
        print("Player has finished the battle and won")
        sys.exit("Thanks for playing!")
    en_turn_start(turn)


def goblin_ai(turn):
    global hp
    global defined_def
    global defined_magi_def
    global en_phys_atk
    global charge_up
    global avalon_stack
    global excalibur_stacks
    global avalon_mult
    global en_mp
    global damage
    global en_hp
    global en_max_mp
    global excalibur_pity
    global excalibur_wait
    global Avalon_wait
    global hasAvalon
    global player_choice
    global attack_division
    Avalon_wait = False
    excalibur_wait = False
    if can_revive and en_revives == 0:
        if not charge_up:
            rng = random.randrange(1,5)
        elif charge_up:
            print("1st Demonic Magick: inner caves of space-time")
            avalon_mult -= 0.5
            print(avalon_mult)
            magic_power = 30
            damage = calculate_magical_damage((en_phys_atk + en_magi_atk) * magic_power, en_defined_def / 16, 0)
            en_phys_atk *= 1.40
            en_mp -= 20
            charge_up = False
        if excalibur_pity == 3:
            rng = 3
        if rng == 1:
            print("The " + enemy_name + " swung their greatsword")
            damage = calculate_physical_damage(en_phys_atk, defined_def)
        if rng == 2:
            print("The " + enemy_name + " rapidly slashed you with their greatsword")
            for i in range(10):
                damage = calculate_physical_damage(en_phys_atk, 0, 8)
                if damage < 0:
                    damage = 0
                if damage != 0:
                    print("Player took " + str(damage) + " damage!")
                hp -= damage
            damage = 0
        if rng == 3:
            print("The " + enemy_name + " laid down")
            en_hp *= 1.20
            en_phys_atk *= 1.20
            en_max_mp += 1.10
            en_mp *= 1.10
            if en_hp > en_max_hp:
                en_hp = en_max_hp
            exalav(turn)
        if rng == 4:
            print("1st Demonic Magick")
            charge_up = True
            damage = 0
        if hp < 0 and prehp > halfhp:
                hp = 1
    elif can_revive:
        rng = random.randrange(1,4)
        if rng == 1:
            print("The " + enemy_name + " swung their club at player")
            damage = calculate_physical_damage(en_phys_atk, defined_def)
        if rng == 2:
            print("The " + enemy_name + " used a rapid barrage")
            for i in range(9):
                damage = calculate_physical_damage(en_phys_atk, defined_def, 7)
                if damage < 0:
                    damage = 0
                hp -= damage
                if damage != 0:
                    print("Player took " + str(damage) + " damage!")
        if rng == 3:
            print("The " + enemy_name + " swung their club at player weakly")
            damage = calculate_physical_damage(en_phys_atk, defined_def, 8)
            print("Allowing them to save their power increasing it by 10%")
            en_phys_atk *= 1.10
            en_max_mp += 1.10
            en_mp *= 1.10
    else:
        print("The " + enemy_name + " swung their club at player")
        attack_division = 1
        damage = calculate_physical_damage(en_phys_atk, defined_def)
    if damage < 0:
        damage = 0
    if en_phys_atk > 700:
        if can_revive and en_revives > 0:
            en_phys_atk = 700
        print("The " + enemy_name + "'s attack can no longer grow")
    if damage != 0:
        print("Player took " + str(damage) + " damage!")
    hp = hp - damage
    if can_revive and en_revives == 0:
        if hp < 0 and prehp > halfhp:
            hp = 1

def mage_ai(turn):
    global status_chance
    global hp
    global burned
    global defined_def
    global defined_magi_def
    global magick_num
    global paralysis
    global used_magick
    global damage
    global en_mp
    global avalon_stack
    global excalibur_stacks
    global charge_up
    global avalon_mult
    global en_magi_atk
    global Avalon_pity
    global excalibur_pity
    global Avalon_wait
    global excalibur_wait
    global en_max_hp
    #The next code will try to make a decision for the attack
    if can_revive and en_revives == 0:
        Avalon_wait = False
        excalibur_wait = False
        used_magick = False
        if not charge_up:
            rng = random.randrange(1,6)
        elif charge_up:
            print("2nd Demonic Magick: Ars Nova")
            avalon_mult -= 0.5
            print(avalon_mult)
            magic_power = 180
            damage = calculate_magical_damage((en_magi_atk) * magic_power, en_defined_def / 16, 0)
            en_magi_atk *= 1.40
            en_hp *= 1.20
            en_max_hp *= 1.20
            en_mp -= 20
            charge_up = False
        if excalibur_pity == 3:
            rng = 4
        if Avalon_pity == 3:
            rng = 4
        if rng == 1:
            print("The mage swung their GreatSword Staff")
            damage = calculate_physical_damage(en_phys_atk, defined_def)
        if rng == 2:
            if en_mp >= 40:
                magick_num = 1
                used_magick = True
                print("The mage sent out a fireball")
                magic_power = 20
                damage = calculate_magical_damage(en_magi_atk, defined_magi_def, magic_power)
                if always_status:
                    status_chance = 1
                else:
                    status_chance = random.randrange(1,17)
        if rng == 3:
            if en_mp >= 45:
                magick_num = 2
                used_magick = True
                print("The mage sent out a Thunder")
                magic_power = 10
                damage = calculate_magical_damage(en_magi_atk, defined_magi_def, magic_power)
                if always_status:
                    status_chance = 1
                else:
                    status_chance = random.randrange(1,9)
        if rng == 4:
            print("Demon King General 2nd Seat: Mage meditated")
            en_mp *= 1.30
            exalav(turn)
        if rng == 5:
            print("2nd Demonic Magick")
            charge_up = True
            damage = 0
        if rng == 6:
            print("Demon King General 2nd Seat: Mage used Heal")
            damage = max_hp * 0.50
            print("Demon King General 2nd Seat: Mage has healed " + str(damage) + " Damage")
            en_hp += damage
            damage = 0
            if en_hp > en_max_hp:
                en_hp = en_max_hp
    elif can_revive:
        Avalon_wait = False
        excalibur_wait = False
        used_magick = False
        rng = random.randrange(1,4)
        if excalibur_pity >= 3:
            rng = 4
        if Avalon_pity >= 3:
            rng = 4
        if rng == 1:
            print("The mage swung their Mystic Staff")
            damage = calculate_physical_damage(en_phys_atk, defined_def)
        if rng == 2:
            if en_mp >= 40:
                magick_num = 1
                used_magick = True
                print("The mage sent out a fireball")
                magic_power = 20
                damage = calculate_magical_damage(en_magi_atk, defined_magi_def, magic_power)
                if always_status:
                    status_chance = 1
                else:
                    status_chance = random.randrange(1,17)
        if rng == 3:
            if en_mp >= 45:
                magick_num = 2
                used_magick = True
                print("The mage sent out a Thunder")
                magic_power = 10
                damage = calculate_magical_damage(en_magi_atk, defined_magi_def, magic_power)
                if always_status:
                    status_chance = 1
                else:
                    status_chance = random.randrange(1,9)
        if rng == 4:
            print("The Mystic Mage meditated")
            en_mp *= 1.30
            exalav(turn)
    else:
        used_magick = False
        rng = random.randrange(1,3)
        if rng == 1:
            print("The mage swung their wand")
            damage = calculate_physical_damage(en_phys_atk, defined_def)
        if rng == 2:
            if en_mp >= 4:
                magick_num = 1
                used_magick = True
                print("The mage sent out a fireball")
                magic_power = 30
                damage = calculate_magical_damage(en_magi_atk, defined_magi_def, magic_power)
                if always_status:
                    status_chance = 1
                else:
                    status_chance = random.randrange(1,17)
    if damage < 0:
        damage = 0
    if damage != 0:
        print("Player took " + str(damage) + " damage!")
    if status_chance == 1 and magick_num == 1:
        print("Player was burned")
        burned = True
    if status_chance == 1 and magick_num == 2:
        print("Player was Paralyzed")
        paralysis = True
    if Avalon_wait:
        Avalon_pity = 0
    else:
        if not hasAvalon:
                Avalon_pity += 1
    if excalibur_wait:
        excalibur_pity = 0
    else:
        if not hasExcalibur:
            if hasAvalon:
                    excalibur_pity += 1
    hp = hp - damage

def berserker_AI(turn):
    global hp
    global damage
    global status_chance
    global berserker_defense_Half
    global halve_stacks
    global avalon_stack
    global hasAvalon
    global Avalon_pity
    global Avalon_wait
    global en_phys_atk
    global mp
    global excalibur_stacks
    global hasExcalibur
    global defined_def
    global max_hp
    global halfhp
    global prehp
    global excalibur_wait
    Avalon_wait = False
    excalibur_wait = False
    match en_revives:
    #Ichor
        case 0:
            rng = random.randrange(1,9)
            if rng == 8:
                en_phys_atk += 50
                print("Heracles Ichor used their Valor A+ skil")
            rng = random.randrange(1,6)
            if excalibur_pity == 3:
                rng = 5
            if rng == 1:
                print("Heracles Ichor used it's Noble Phantasm 'Breakage Giganomachia, Slaying the Hundred Gods'.")
                for i in range(10):
                    #damage = ((rng * en_phys_atk))/6
                    damage = calculate_physical_damage(en_phys_atk, 0, 6)
                    if damage < 0:
                        damage = 0
                    if damage != 0:
                        print("Player took " + str(damage) + " damage!")
                    hp -= damage
                status_chance = random.randrange(1,4)
                if status_chance == 1:
                    if not berserker_defense_Half:
                        print("berserker's posistion has been weakened")
                        berserker_defense_Half = True
                        halve_stacks = 2
                    else:
                        print("berserker's posistion has been further weakened")
                        halve_stacks += 1
                if hp < 0 and prehp > halfhp:
                    hp = 1
                damage = 0
            if rng == 2:
                print("Heracles Ichor used their Glorious Greatsword")
                damage = calculate_physical_damage(en_phys_atk, defined_def) * 4
                if damage < 0:
                    damage = 0
                if damage != 0:
                    print("Player took " + str(damage) + " damage!")
                en_phys_atk *= 1.20
                print("Heracles ichor's power has increased by 20%")
            if rng == 3:
                print("Heracles Ichor used Cold-Hearted Unyeilding Bow")
                damage = calculate_physical_damage(en_phys_atk, defined_def) * 8
                if damage < 0:
                    damage = 0
                if damage != 0:
                    print("Player took " + str(damage) + " damage!")
                print("Player's mp decreased by 20%")
                mp *= 0.20
            if rng == 4:
                print("Heracles Ichor used Battleaxe of Destruction")
                damage = calculate_physical_damage(en_phys_atk, 0)
                if damage > 799 and prehp > halfhp:
                    damage = 799
                if damage < 0:
                    damage = 0
                if damage != 0:
                    print("Player took " + str(damage) + " damage!")
                damage += 200
                print("Player took 200 instant damage")
            if rng == 5:
                if not hasExcalibur:
                    print("Heracles Ichor's madness enchancement paralyzed him")
                    excalibur_stacks += 1
                    hp += (max_hp/30)
                    Avalon_wait = True
                else:
                    print("Heracles Ichor was paralyzd by his extreme madness")
        case 1:
            rng = random.randrange(1,5)
            if Avalon_pity == 4:
                rng = 4
            if rng == 1:
                print("Bersker used it's Noble Phantasm 'Nine lives'.")
                for i in range(9):
                    damage = calculate_physical_damage(en_phys_atk, defined_def, 2)
                    if damage != 0:
                        print("Player took " + str(damage) + " damage!")
                    hp -= damage
                status_chance = random.randrange(1,4)
                if status_chance == 1:
                    if not berserker_defense_Half:
                        print("berserker's posistion has been weakened")
                        berserker_defense_Half = True
                        halve_stacks = 2
                    else:
                        print("berserker's posistion has been further weakened")
                        halve_stacks += 1
                damage = 0
            if rng == 2:
                print("Berserker threw a boulder at you")
                damage = calculate_physical_damage(en_phys_atk, defined_def) * 4
                if damage != 0:
                    print("Player took " + str(damage) + " damage!")
            if rng == 3:
                print("Berserker stomped and summoned an earthquake")
                damage = calculate_physical_damage(en_phys_atk, defined_def) * 6
                if damage != 0:
                    print("Player took " + str(damage) + " damage!")
            if rng == 4:
                print("Berserker stoood still")
                exalav(turn)
        case 2:
            rng = random.randrange(1,5)
            if Avalon_pity == 4:
                rng = 4
            if rng == 1:
                print("Bersker used it's Noble Phantasm 'Nine lives'.")
                for i in range(9):
                    damage = calculate_physical_damage(en_phys_atk, defined_def, 2)
                    if damage != 0:
                        print("Player took " + str(damage) + " damage!")
                    hp -= damage
                status_chance = random.randrange(1,4)
                if status_chance == 1:
                    if not berserker_defense_Half:
                        print("berserker's posistion has been weakened")
                        berserker_defense_Half = True
                        halve_stacks = 2
                    else:
                        print("berserker's posistion has been further weakened")
                        halve_stacks += 1
                damage = 0
            if rng == 2:
                print("Berserker threw a boulder at you")
                damage = calculate_physical_damage(en_phys_atk, defined_def) * 4
                if damage != 0:
                    print("Player took " + str(damage) + " damage!")
            if rng == 3:
                print("Berserker stomped and summoned an earthquake")
                damage = calculate_physical_damage(en_phys_atk, defined_def) * 6
                if damage != 0:
                    print("Player took " + str(damage) + " damage!")
            if rng == 4:
                print("Berserker stoood still")
                exalav(turn)
        case x if 2 < x <= 9:
            rng = random.randrange(1,4)
            if rng == 1:
                print("Bersker used it's Noble Phantasm 'Nine lives'.")
                for i in range(9):
                    damage = calculate_physical_damage(en_phys_atk, defined_def, 4)
                    if damage != 0:
                        print("Player took " + str(damage) + " damage!")
                    hp -= damage
                status_chance = random.randrange(1,4)
                if status_chance == 1:
                    if not berserker_defense_Half:
                        print("berserker's posistion has been weakened")
                        berserker_defense_Half = True
                        halve_stacks = 2
                    else:
                        print("berserker's posistion has been further weakened")
                        halve_stacks += 1
                damage = 0
            if rng == 2:
                print("Berserker threw a boulder at you")
                damage = calculate_physical_damage(en_phys_atk, defined_def)
                if damage != 0:
                    print("Player took " + str(damage) + " damage!")
            if rng == 3:
                print("Berserker stomped and summoned an earthquake")
                damage = calculate_physical_damage(en_phys_atk, defined_def) * 2
                if damage != 0:
                    print("Player took " + str(damage) + " damage!")
        case _:
            rng = random.randrange(1,3)
            if rng == 1:
                print("Bersker used it's Noble Phantasm 'Nine lives'.")
                for i in range(9):
                    damage = calculate_physical_damage(en_phys_atk, defined_def, 4)
                    if damage != 0:
                        print("Player took " + str(damage) + " damage!")
                    hp -= damage
                status_chance = random.randrange(1,4)
                if status_chance == 1:
                    if not berserker_defense_Half:
                        print("berserker's posistion has been weakened")
                        berserker_defense_Half = True
                        halve_stacks = 2
                    else:
                        print("berserker's posistion has been further weakened")
                        halve_stacks += 1
                damage = 0
            if rng == 2:
                print("Berserker threw a boulder at you")
                damage = calculate_physical_damage(en_phys_atk, defined_def)
                if damage != 0:
                    print("Player took " + str(damage) + " damage!")
    hp = hp - damage

def golem_ai(turn):
    global status_chance
    global hp
    global burned
    global defined_def
    global defined_magi_def
    global en_mp
    global en_hp
    global damage
    global en_magi_atk
    global en_phys_atk
    global avalon_stack
    global excalibur_stacks
    global charge_up
    global self_turn
    global slow_start
    global extra_math
    global phys_def_break
    global avalon_mult
    if self_turn < 3:
        slow_start = True
        extra_math = 1 / 3
    if can_revive and en_revives == 0:
        if not charge_up:
            rng = random.randrange(1,5)
        elif charge_up:
            print("3rd Demonic Magick: True full potential of a Golem")
            avalon_mult -= 0.5
            magic_power = 180
            damage = calculate_magical_damage((en_phys_def * en_magi_atk) * magic_power, defined_magi_def / 16, 0)
            en_mp -= 20
            charge_up = False
        if en_mp < 1:
            en_hp = 0
        if rng == 1:
            print("The golem swung their arm")
            damage = calculate_physical_damage(en_phys_atk, defined_def)
        if rng == 2:
            if en_mp >= 20:
                print("The golem used a mouth beam")
                magic_power = 30
                damage = calculate_magical_damage(en_magi_atk, defined_magi_def, magic_power)
                en_mp -= 20
        if rng == 3:
            print("The golem recharged")
            en_mp += 20
            exalav(turn)
        if rng == 4:
            print("3rd Demonic Magick")
            charge_up = True
    elif can_revive:
        rng = random.randrange(1,4)
        if en_mp < 1:
            en_hp = 0
        if rng == 1:
            print("The golem swung their arm")
            damage = calculate_physical_damage(en_phys_atk, defined_def)
        if rng == 2:
            if en_mp >= 20:
                print("The golem used a mouth beam")
                magic_power = 30
                damage = calculate_magical_damage(en_magi_atk, defined_magi_def, magic_power)
                en_phys_atk *= 1.20
                en_magi_atk *= 1.20
                en_mp -= 20
        if rng == 3:
            print("The golem recharged")
            en_mp += 20
            exalav(turn)
    else:
        rng = random.randrange(1,3)
        if en_mp < 1:
            en_hp = 0
        if rng == 1:
            print("The golem swung their arm")
            damage = calculate_physical_damage(en_phys_atk, defined_def)
        if rng == 2:
            if en_mp >= 20:
                print("The golem used a mouth beam")
                magic_power = 30
                damage = calculate_magical_damage(en_magi_atk, defined_magi_def, magic_power)
                en_mp -= 20
    if slow_start:
        damage *= extra_math
    if damage < 0:
        damage = 0
    if damage != 0:
        print("Player took " + str(damage) + " damage!")
    self_turn += 1
    hp = hp - damage
    extra_math = 0

def angel_ai(turn):
    global status_chance
    global hp
    global burned
    global defined_def
    global defined_magi_def
    global en_mp
    global en_hp
    global damage
    global en_magi_atk
    global en_phys_atk
    global avalon_stack
    global excalibur_stacks
    global charge_up
    global self_turn
    global slow_start
    global extra_math
    global phys_def_break
    global avalon_mult
    global used_magick
    global rng
    damage = 0
    if en_revives and en_revives == 0:
        if not charge_up:
            rng = random.randrange(1,6)
            used_magick = False
            if excalibur_pity >= 3:
                rng = 5
            if Avalon_pity >= 3:
                rng = 5
        elif charge_up:
            if used_magick:
                print("Demon King General 4th Seat: Fallen Angel shot a beam of pure darkness")
                magic_power = 36
                damage = calculate_magical_damage(en_magi_atk * magic_power, defined_def/16, 0)
                en_magi_atk *= 1.20
                charge_up = False
            else:
                print("Demon King General 4th Seat: Fallen Angel flew down")
                magic_power = 180
                damage = calculate_magical_damage(en_magi_atk + en_phys_atk, defined_def/16, magic_power)
                en_phys_atk *= 1.20
                charge_up = False
        if rng == 1:
            print("Demon King General 4th Seat: Fallen Angel swung their sword of dark")
            damage = calculate_physical_damage(en_phys_atk, defined_def)
        if rng == 2:
            if en_mp >= 20:
                print("Demon King General 4th Seat: Fallen Angel summoned a magic circle")
                used_magick = True
                charge_up = True
                magic_power = 30
                damage = calculate_magical_damage(en_magi_atk, defined_magi_def, magic_power)
                en_mp -= 20
            else:
                print("The angel lowered their arms")
                exalav(turn)
        if rng == 3:
            damage = 0
            print("Demon King General 4th Seat: Fallen Angel flew up")
            charge_up = True
        if rng == 4:
            if en_mp >= 20:
                print("Demon King General 4th Seat: Fallen Angel summoned dark ice across the field")
                damage = calculate_magical_damage(en_magi_atk, defined_magi_def, 0)
            else:
                print("Demon King General 4th Seat: Fallen Angel lowered their arms")
                exalav(turn)
        if rng == 5:
            print("The recharged their mana")
            en_mp = en_max_mp
            exalav(turn)
    elif en_revives:
        if not charge_up:
            rng = random.randrange(1,6)
            used_magick = False
            if excalibur_pity >= 3:
                rng = 5
            if Avalon_pity >= 3:
                rng = 5
        elif charge_up:
            if used_magick:
                print("The Fallen Angel shot a beam of pure darkness")
                magic_power = 36
                damage = calculate_magical_damage(en_magi_atk * magic_power, defined_def/16, 0)
                en_magi_atk *= 1.20
                charge_up = False
            else:
                print("The Fallen Angel flew down")
                magic_power = 180
                damage = calculate_magical_damage(en_magi_atk + en_phys_atk, defined_def/16, magic_power)
                en_phys_atk *= 1.20
                charge_up = False
        if rng == 1:
            print("The Fallen Angel swung their sword of dark")
            damage = calculate_physical_damage(en_phys_atk, defined_def)
        if rng == 2:
            if en_mp >= 20:
                print("The Fallen Angel summoned a magic circle")
                used_magick = True
                charge_up = True
                magic_power = 30
                damage = calculate_magical_damage(en_magi_atk, defined_magi_def, magic_power)
                en_mp -= 20
            else:
                print("They angel lowered their arms")
                exalav(turn)
        if rng == 3:
            damage = 0
            print("The Fallen Angel flew up")
            charge_up = True
        if rng == 4:
            if en_mp >= 20:
                print("The Fallen Angel summoned dark ice across the field")
                damage = calculate_magical_damage(en_magi_atk, defined_magi_def, 0)
            else:
                print("They angel lowered their arms")
                exalav(turn)
        if rng == 5:
            print("The recharged their mana")
            en_mp = en_max_mp
            exalav(turn)
    else:
        if not charge_up:
            rng = random.randrange(1,4)
            used_magick = False
        elif charge_up:
            en_hp *= 1.20
            en_magi_atk *= 1.20
            en_phys_atk *= 1.20
            print("The angel flew down")
            magic_power = 180
            damage = calculate_magical_damage(en_magi_atk + en_phys_atk, defined_def/16, magic_power)
            charge_up = False
        if rng == 1:
            print("The Angel swung their sword of light")
            damage = calculate_physical_damage(en_phys_atk, defined_def)
        if rng == 2:
            if en_mp >= 200:
                print("The Angel summoned a magic circle")
                print("Out shot a beam of light")
                magic_power = 30
                damage = calculate_magical_damage(en_magi_atk, defined_magi_def, magic_power)
                en_mp -= 20
            else:
                print("They angel lowered their arms")
                exalav(turn)
        if rng == 3:
            damage = 0
            print("The angel flew up")
            charge_up = True
    if damage < 0:
        damage = 0
    if damage != 0:
        print("Player took " + str(damage) + " damage!")
    self_turn += 1
    hp = hp - damage

def TDK_AI(turn):
    global status_chance
    global hp
    global burned
    global defined_def
    global defined_magi_def
    global en_mp
    global en_hp
    global damage
    global en_magi_atk
    global en_phys_atk
    global avalon_stack
    global excalibur_stacks
    global charge_up
    global self_turn
    global slow_start
    global extra_math
    global phys_def_break
    global avalon_mult
    global en_max_hp
    global en_max_mp
    global en_phys_def
    global en_magi_def
    global rng
    global Avalon_pity
    global excalibur_pity
    global en_burned
    damage = 0
    if self_turn < 3 and en_revives != max_en_revives:
        print("true")
        slow_start = True
        extra_math = 1 / 2
    if self_turn < 3:
        if max_en_revives == en_revives:
            en_max_hp = 45000.0
            en_max_mp = 40000
            en_phys_atk = 190
            en_phys_def = 75
            en_magi_atk = 190
            en_magi_def = 45
    elif self_turn == 11:
        if max_en_revives == en_revives:
            en_max_hp = 200000.0
            en_max_mp = 40000
            en_phys_atk = 1000
            en_phys_def = 200
            en_magi_atk = 1000
            en_magi_def = 225
            en_hp = en_max_hp
            en_mp = en_max_mp
    elif self_turn ==22:
        if max_en_revives == en_revives:
            en_max_hp = 450000.0
            en_max_mp = 40000
            en_phys_atk = 2000
            en_phys_def = 750
            en_magi_atk = 2000
            en_magi_def = 450
            en_hp = en_max_hp
            en_mp = en_max_mp
    if not charge_up:
        rng = random.randrange(1,7)
        if excalibur_pity >= 3:
            rng = 3
        if Avalon_pity >= 3:
            rng = 3
    elif charge_up:
        print("True Demonic Magick: True Perfect Black")
        avalon_mult -= 0.5
        print(avalon_mult)
        magic_power = 180
        damage = calculate_magical_damage(en_magi_atk * magic_power, defined_magi_def / 16, 0)
        en_phys_atk *= 1.05
        en_magi_atk *= 1.20
        en_phys_def *= 1.05
        en_magi_def *= 1.05
        en_mp -= 20
        en_hp -= en_hp * 0.02
        charge_up = False
        rng = 7
    if en_mp < 1:
            en_hp = 0
    if rng == 1:
        print("The Demon King swung their Greataxe")
        damage = calculate_physical_damage(en_phys_atk, defined_def, 2)
        if prehp > halfhp and damage > hp:
            damage = hp - 1
    if rng == 2:
        if en_mp >= 200:
            print("The Demon King used Dark Lightning")
            magic_power = 30
            damage = calculate_magical_damage(en_magi_atk, defined_magi_def, magic_power)
            if always_status:
                status_chance = 1
            else:
                status_chance = random.randrange(1,9)
            en_mp -= 200
    if rng == 3:
        print("The Demon King recharged")
        en_mp *= 1.5
        self_turn -= 2
        exalav(turn)
    if rng == 4:
        print("True Demonic Magick")
        charge_up = True
    if rng == 5:
        print("The Demon King punched the air and the wind hits you")
        damage = calculate_physical_damage(en_phys_atk, defined_def, 8, 3)
        print("Their conserved power increased their power")
        en_phys_atk *= 1.20
    if rng == 6:
            print("The Demon King Mage used Heal")
            damage = (en_max_hp * 0.50) - (en_max_hp - en_hp)
            print("The Demon King has healed " + str(damage) + " Damage")
            if en_burned:
                en_burned = False
                print("His burn was cured")
            en_hp += damage
            damage = 0
            if en_hp > en_max_hp:
                en_hp = en_max_hp
    if slow_start:
        damage *= extra_math
    if damage < 0:
        damage = 0
    if damage != 0:
        print("Player took " + str(damage) + " damage!")
    self_turn += 1
    hp = hp - damage
    if en_hp > en_max_hp:
        en_hp = en_max_hp
    extra_math = 0

def enemy_revives(turn):
    global en_phys_atk
    global en_phys_def
    global en_magi_def
    global en_burned
    global en_hp
    global en_max_hp
    global en_revives
    global berserker_defense_Half
    global halve_stacks
    global enemy_mana_drain
    global phys_def_break
    global enemy_name
    global start_pity
    global en_mp
    global en_magi_atk
    global en_max_mp
    global self_turn
    global hasAvalon
    global invincible
    global revive_cure
    global readyavex
    global revive_count
    global test_loop
    global avalon_mult
    start_pity = False
    print(enemy_name + " has revived")
    en_revives -= 1
    if revive_cure:
        en_burned = False
        berserker_defense_Half = False
        halve_stacks = 1
        enemy_mana_drain = False
    match enemy_id:
        case 3:
            match en_revives:
                case 10:
                    print("Player: He revived?!")
                    en_max_hp = 2050.0
                    en_phys_atk = 90
                    en_phys_def = 45
                    en_magi_def = 55
                case 9:
                    print("Player: Are you kidding me...")
                    en_max_hp = 2300.0
                    en_phys_atk = 130
                    en_phys_def = 70
                    en_magi_def = 80
                case 8:
                    print("Player: Okay this is getting tedious!")
                    en_max_hp = 2450.0
                    en_phys_atk = 190
                    en_phys_def = 100
                    en_magi_def = 130
                case 7:
                    en_max_hp = 2500.0
                    en_phys_atk = 230
                    en_phys_def = 140
                    en_magi_def = 190
                case 2:
                    print("[He found his true weapon, Marmyadose]")
                    readyavex = True
                    en_max_hp = 3700.0
                    en_phys_atk = 360
                    en_phys_def = 280
                    en_magi_def = 230
                    start_pity = True
                case 1:
                    print("[His full aura weakened your defenses]")
                    readyavex = True
                    en_max_hp = 4000.0
                    en_phys_atk = 440
                    en_phys_def = 380
                    en_magi_def = 320
                    phys_def_break += 0.25
                case 0:
                    print("[The grand of the berserker class has awaken, Heracles Ichor]")
                    readyavex = True
                    en_max_hp = 40000.0
                    en_phys_atk = 500
                    en_phys_def = 4000
                    en_magi_def = 380
                    phys_def_break += 0.75
                    en_max_mp = 16000
                    en_mp = en_max_mp
                    enemy_name = "Heracles Ichor"
                case _:
                    en_max_hp += 300.0
                    en_phys_atk += 60
                    en_phys_def += 30
                    en_magi_def += 20
        case 4:
            if en_revives > 0:
                self_turn = 0
                enemy_name = "Abyssal Golem"
                readyavex = True
                en_max_hp = 1000.0
                en_max_mp = 1000
                en_phys_atk = 250
                en_phys_def = 300
                en_magi_atk = 225
                en_magi_def = 300
            if en_revives == 0:
                enemy_name = "Demon King General 3rd Seat: Golem"
                readyavex = True
                en_max_hp = 45000.0
                en_max_mp = 40000
                en_phys_atk = 2000
                en_phys_def = 750
                en_magi_atk = 450
                en_magi_def = 450
        case 1:
            if en_revives > 0:
                self_turn = 0
                enemy_name = "Elite Goblin"
                en_max_hp = 650.0
                en_max_mp = 850
                en_phys_atk = 100
                en_phys_def = 50
                en_magi_atk = 0
                en_magi_def = 25
            elif en_revives == 0:
                enemy_name = "Demon King General 1st Seat: Goblin"
                readyavex = True
                en_max_hp = 5500.0
                en_max_mp = 50000
                en_phys_atk = 700
                en_phys_def = 500
                en_magi_atk = 1000
                en_magi_def = 225
                print("The world realized the power inbalance and reflexively saved you")
                hasAvalon = True
                invincible = True
        case 2:
            if en_revives > 0:
                enemy_name = "Mystic Mage"
                readyavex = True
                en_max_hp = 650.0
                en_max_mp = 1700
                en_phys_atk = 50
                en_phys_def = 150
                en_magi_atk = 130
                en_magi_def = 170
            elif en_revives == 0:
                enemy_name = "Demon King General 2nd Seat: Mage"
                readyavex = True
                en_max_hp = 3650.0
                en_max_mp = 60000
                en_phys_atk = 400
                en_phys_def = 450
                en_magi_atk = 800
                en_magi_def = 450
        case 5:
            if en_revives > 0:
                enemy_name = "Fallen Angel"
                readyavex = True
                en_max_hp = 1200.0
                en_hp = en_max_hp
                en_max_mp = 10000
                en_mp = en_max_mp
                en_phys_atk = 70
                en_phys_def = 50
                en_magi_atk = 100
                en_magi_def = 50
            elif en_revives == 0:
                enemy_name = "Demon King General 4th Seat: Fallen Angel"
                readyavex = True
                en_max_hp = 9000.0
                en_max_mp = 60000
                en_phys_atk = 1000
                en_phys_def = 550
                en_magi_atk = 1000
                en_magi_def = 550
        case 6:
            en_max_hp = 450000.0
            en_max_mp = 40000
            en_phys_atk = 2000
            en_phys_def = 750
            en_magi_atk = 2000
            en_magi_def = 450
            revive_count = en_revives
            phys_def_break = 1
            if stat_check:
                print("Revive Count: " + str(revive_count))
            while revive_count != max_en_revives:
                if revive_count == 2:
                    en_max_hp += 5000.0
                    en_phys_atk += 5000
                    en_phys_def += 2500
                    en_magi_def += 2500
                    en_magi_atk += 5000
                if revive_count == 1:
                    en_max_hp += 10000.0
                    en_phys_atk += 10000
                    en_phys_def += 5000
                    en_magi_def += 5000
                    en_magi_atk += 10000
                if revive_count == 0:
                    en_max_hp += 15000.0
                    en_phys_atk += 15000
                    en_phys_def += 7500
                    en_magi_def += 7500
                    en_magi_atk += 15000
                phys_def_break += 0.25
                avalon_mult -= 0.50
                revive_count += 1
                test_loop += 1
            if stat_check:
                print("Revive Stat Loops: " + str(test_loop))
            test_loop = 0
    en_hp = en_max_hp
    en_mp = en_max_mp

def stats(turn):
    global max_hp
    global hp
    global max_mp
    global mp
    global phys_atk
    global phys_def
    global magi_atk
    global magi_def
    global defined_def
    global defined_magi_def
    global mult_def
    global phys_def_break
    global Recursive_Magic
    global choice
    print("----------------------------------")
    print("Max_HP: " + str(max_hp))
    print("HP: " + str(hp))
    print("Max_MP: " + str(max_mp))
    print("MP: " + str(mp))
    print("Attack: " + str(phys_atk))
    print("Defense: " + str(phys_def))
    print("Magical Attack: " + str(magi_atk))
    print("Magical Defense: " +  str(magi_def))
    print("Defined Attack: " + str(defined_atk))
    print("Defined Defense: " + str(defined_def))
    print("Magical Defined Attack: " + str(defined_magi_atk))
    print("Magical Defined Defense: " + str(defined_magi_def))
    print("Multiply Defense by: " + str(mult_def))
    print("Physical Defense Break: " + str(phys_def_break))
    print("Recursive Magic: " + str(Recursive_Magic))
    choice = int(input("Do you want to see the enemies stats?(1 = yes, 2 = no)"))
    match choice:
        case 1:
            print("----------------------------------")
            print("Enemy Name: " + str(enemy_name))
            print("Max_HP: " + str(en_max_hp))
            print("HP: " + str(en_hp))
            print("Max_MP: " + str(en_max_mp))
            print("MP: " + str(en_mp))
            print("Attack: " + str(en_phys_atk))
            print("Defense: " + str(en_phys_def))
            print("Magical Attack: " + str(en_magi_atk))
            print("Magical Defense: " +  str(en_magi_def))
        case 2:
            mp = mp
    print("----------------------------------")
    player_choice(turn)

def devtools(choice):
    global turn
    global mp
    global hp
    global always_status
    global avalon_stack
    global mult_def
    global en_revives
    global can_revive
    global en_hp
    global invincible
    global Recursive_Magic
    global hasAvalon
    global stat_check
    global enemy_mana_drain
    global en_paralysis
    print("----------------------------------")
    print("You successfully open the Devtool menu")
    print("1987. Get rid of Mana")
    print("1048596. death test")
    print("310. no longer resists status")
    print("284. Heracles live 2")
    print("353. Avalon stack test")
    print("85181312419. Heracles Ichor")
    print("411314. revive form 1")
    print("851212. revive form 2")
    print("1234567890. Visionary on Stats")
    print("987654321. Visionary on Stats(and mana drain)")
    print("1611811225265. Paralyze enemy")
    print("1315189. Death(0 hp)")
    print("1.Back")
    choice = int(input("Choice your decision: "))
    match choice:
        case 1987:
            print("You used DevTool, and drained all MP")
            mp = 0
        case 1048596:
            print("You used DevTool, drained your life force")
            hp = 0
        case 310:
            print("You used DevTool Barghest, You can never resist status effects :)")
            always_status = True
        case 284:
            print("You used DevTool, You just kick started your doom :)")
            mult_def = 22.5
            en_revives = 3
            can_revive = True
            en_hp = 0
            hp = 2000
        case 353:
            print("You used DevTool, You gained avalon stack)")
            avalon_stack += 1
        case 85181312419:
            print("You used DevTool, Heracles Ichor has been awakened")
            en_revives = 1
            en_hp = 0
            hasAvalon = True
            mult_def = 16
            Recursive_Magic = 9000
            invincible = True
            can_revive = True
        case 411314:
            en_revives = 3
            can_revive = True
            en_hp = 0
            invincible = True
        case 851212:
            en_revives = 1
            can_revive = True
            en_hp = 0
            invincible = True
            Recursive_Magic = 9000
            hasAvalon = True
        case 1234567890:
            print("Activated DevTool Visionary")
            stat_check = True
        case 987654321:
            print("Activated DevTool ExtraSensory Visionary")
            stat_check = True
            enemy_mana_drain = True
        case 1611811225265:
            print("Activated DevTool paralyze")
            en_paralysis = True
        case 1315189:
            print("Activated DevTool of death")
            en_hp = 0
        case 1:
            print("----------------------------------")
            player_choice(turn)
        case _:
            print("Choose a valid devtool")
            print("----------------------------------")
            player_choice(turn)

def exalav(turn):
    global avalon_stack
    global excalibur_stacks
    global hasAvalon
    global hasExcalibur
    global Avalon_wait
    global excalibur_wait
    global enemy_name
    global enemy_id
    global damage
    damage = 0
    if not hasAvalon:
        print("You wandered around to find a way to escape")
        avalon_stack += 1
        Avalon_wait = True
    elif hasAvalon and not hasExcalibur and not enemy_id == 3:
        print("You wandered around to find a way to escape")
        excalibur_stacks += 1
        excalibur_wait = True
    elif hasAvalon and not hasExcalibur and can_revive and en_revives == 0 and enemy_id == 3:
        print("You wandered around to find a way to escape")
        excalibur_stacks += 1
        excalibur_wait = True
    else:
        match enemy_id:
            case 1:
                print("The " + enemy_name + " stared at you")
            case 2:
                print("The " + enemy_name + " stared at you")
            case 3:
                print("Berserker looks angry")
            case 4:
                print("The " + enemy_name + " stared at you")
            case 5:
                print("the " + enemy_name + " floated there")

def avapitwait(turn):
    global readyavex
    global Avalon_wait
    global Avalon_pity
    global can_revive
    global en_revives
    global excalibur_wait
    global excalibur_pity
    global hasAvalon
    global hasExcalibur
    if readyavex:
        if Avalon_wait:
            Avalon_pity = 0
            Avalon_wait = False
        else:
            if not hasAvalon:
                Avalon_pity += 1
            if not enemy_id == 3:
                if excalibur_wait:
                    excalibur_pity = 0
                    excalibur_wait = False
                else:
                    if not hasExcalibur:
                        if hasAvalon:
                            excalibur_pity += 1
            elif can_revive and en_revives == 0 and enemy_id == 3:
                if excalibur_wait:
                    excalibur_pity = 0
                    excalibur_wait = False
                else:
                    if not hasExcalibur:
                        if hasAvalon:
                            excalibur_pity += 1

def calculate_physical_damage(attack, defense, division=1, crit=16, crit_bonus=1.5):
    rng = random.randrange(80,101) / 100
    damage = (rng * attack) - defense
    if division != 1:
        damage /= division
    if random.randrange(1, crit+1) == crit:
        print("CRITICAL HIT")
        damage *= crit_bonus
    return damage if damage > 0 else 0

def calculate_magical_damage(attack, defense, power,division=1, crit=16, crit_bonus=1.5):
    rng = random.randrange(80,101) / 100
    damage = ((rng * attack) + power) - defense
    if division != 1:
        damage /= division
    if random.randrange(1, crit+1) == crit:
        print("CRITICAL HIT")
        damage *= crit_bonus
    return damage if damage > 0 else 0

import sys
sys.setrecursionlimit(50000)
global max_en_revives
global test_loop
global excalibur_stacks
global hasExcalibur
global defined_atk
global defined_magi_atk
global halfhp
global charge_up
global slow_start
global extra_math
global self_turn
global avalon_mult
global revive_cure
global excalibur_pity
global excalibur_wait
global Avalon_wait
global magick_num
global paralysis
global readyavex
global player_turn
global attack_division
global revive_count
global en_paralysis
en_paralysis = False
revive_count = 0
attack_division = 1
player_turn = True
readyavex = False
stat_check = False
paralysis = False
magick_num = 0
Avalon_pity = 0
Avalon_wait = False
excalibur_wait = False
excalibur_pity = 0
revive_cure = False
avalon_mult = 6
self_turn = 0
extra_math = 0
slow_start = False
charge_up = False
hasExcalibur = False
excalibur_stacks = 0
test_loop = 0
max_en_revives = 0
Recursive_Magic = 0
phys_def_break = 1
halve_stacks = 1
en_burned = False
en_revives = 0
enemy_mana_drain = False
berserker_defense_Half = False
always_status = False
status_chance = 0
burned = False
hasAvalon = False
invincible = False
turn = 0
max_hp = 120.0
hp = max_hp
max_mp = 20
mp = max_mp
phys_atk = 30
phys_def = 15
magi_atk = 30
magi_def = 15
defined_def = phys_def + .0
defined_magi_def = magi_def + .0
defined_atk = phys_atk + .0
defined_magi_atk = magi_atk + .0
mult_def = 1
halfhp = max_hp / 2
import random
rng = 1
rng = random.randrange(1,7) #picks an enemy for you to fight randomly
enemy_id = rng
can_revive = False
match enemy_id:
    case 1:
        enemy_name = "Goblin"
        en_max_hp = 110.0
        en_max_mp = 0
        en_phys_atk = 25
        en_phys_def = 10
        en_magi_atk = 0
        en_magi_def = 5
    case 2:
        enemy_name = "Mage"
        en_max_hp = 70.0
        en_max_mp = 40
        en_phys_atk = 5
        en_phys_def = 5
        en_magi_atk = 30
        en_magi_def = 30
    case 3:
        max_en_revives = 11
        en_revives = max_en_revives
        enemy_name = "Berserker"
        en_max_hp = 2000.0
        en_max_mp = 3000
        en_phys_atk = 70
        en_phys_def = 20
        en_magi_atk = 0
        en_magi_def = 20
        can_revive = True
        revive_cure = True
        en_defined_def = en_phys_def
        en_defined_magi_def = en_magi_def
    case 4:
        enemy_name = "Golem"
        en_max_hp = 450.0
        en_max_mp = 500
        en_phys_atk = 50
        en_phys_def = 40
        en_magi_atk = 35
        en_magi_def = 15
    case 5:
        enemy_name = "Angel"
        en_max_hp = 600.0
        en_max_mp = 5000
        en_phys_atk = 35
        en_phys_def = 25
        en_magi_atk = 50
        en_magi_def = 25
    case 6:
        enemy_name = "The Demon King"
        readyavex = True
        en_max_hp = 450000.0
        en_max_mp = 40000
        en_phys_atk = 2000
        en_phys_def = 750
        en_magi_atk = 2000
        en_magi_def = 450
        max_en_revives = 3
        can_revive = True
        en_revives = max_en_revives
en_hp = en_max_hp
en_mp = en_max_mp
if __name__ == "__main__":
    first_turn_start(turn)
else:
    print("Addon Test Mode Activated")
    addon_used = True
#test1