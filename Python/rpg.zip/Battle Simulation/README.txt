#rpg.py(Battle Simulation)

#Reason
I made this project in mind of me wanting to make my first fully fledged game and to test out my coding skills

#Features
- RNG that works for primitive AI
-Damage formula that uses RNG
- Random enemy system
-Enemy revies and form changes
-Secret Debug codes

#Limitations
Due to the use of recursion for the game there is a set amount of actions till the game crashes.

#Download
As this is a raw python file. You will need python downloaded onto your pc and by me using the case function.
the python version needed is 3.10 or higher. go to the official python website and download the newest version.
No external libs or packages are required to run this program.

#How to run
Use your interpreter of choice or use windows PowerShell or your os's version of PowerShell.

#story
Player is a girl in a small village who decided to go outside her village and see the world. 
But she on her journey. She was cursed by a witch which put her in a time loop. 
Where she would have to endlessly fight enemies in the end if she dies she loops if she triumphs she loops. 
Of course the witch isn't cruel so she have player the abilities needed to beat her foes.

#IP's
Yes there is multiple pieces of content in this application relating to fate. As I am a huge fan of fate there certainly will be more.

If there's any issues you want to tell me about just email me. Which is in the footer of my website.