#rpg.py(Battle Simulation)

#Reason
I made this project in mind of me wanting to make my first fully fledged game and to test out my coding skills

#Features
- RNG that works for primitive AI
-Damage formula that uses RNG
- Random enemy system
-Enemy revies and form changes
-Secret Debug codes
-Can be imported for any addons

#Limitations
Due to the use of recursion for the game there is a set amount of actions till the game crashes.

#Download
As this is a raw python file. You will need python downloaded onto your pc and by me using the case function.
the python version needed is 3.10 or higher. go to the official python website and download the newest version.
No external libs or packages are required to run this program.

#How to run
Use your interpreter of choice or use windows PowerShell or your os's version of PowerShell.

#story
Player(Pu-Rei-Ya) MC(N-Shi) is a girl in a small village. 
She is the daugther of NPC(N-Pi-Shi) MC and CPU(Shi-Pi-Yu) MC.
Player decided to go outside her village and see the world.
But she needed equipment for that so she asked her father to make armor and a sword for her, which he obliged. 
But she on her journey. She found a witch who would give her a magic item in return for helping her.
As the good person Player is she helped the which.
But instead she was cursed by a witch which put her in a time loop. 
Where she would have to endlessly fight enemies in the end if she dies she loops if she triumphs she loops. 
But it wasnt really a 'timeloop' it was a pocket dimension made by the witch which allowed her to control everything inside.
The pocket dimenion was a perfect replica of their world even to the parts the witch didnt know existed.
Of course the witch isn't cruel so she have player the abilities needed to beat her foes.
She gave player multiple spells that would keep her weak but could make her strong enough to beat her foes.
Even having DevTools which are cosmic authorities that change the world around her.

#IP's
Yes there is multiple pieces of content in this application relating to fate. As I am a huge fan of fate there certainly will be more.

If there's any issues you want to tell me about just email me. Which is in the footer of my website.