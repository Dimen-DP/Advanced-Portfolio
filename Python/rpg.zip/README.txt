#rpg.py(Battle Simulation)

#Features
A battle simulator with RNG, damage formula's, working random enemy system plus an enemy revive and form change system(using debug codes ofc)

#story
Player is a girl in a small village who decided to go outside her village and see the world. But she on her journey. She was cursed by a witch which put her in a time loop. where she would have to endlessly fight enemies in the end if she dies she loops if she triumphs she loops. Of course the witch isn't cruel so she have player the abilities needed to beat her foes.

If there's any issues you want to tell me about just email me (: