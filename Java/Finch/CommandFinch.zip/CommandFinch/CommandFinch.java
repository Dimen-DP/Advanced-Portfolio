import java.util.Scanner;

public class CommandFinch {
    public static void main(String[] args) {
        Finch myFinch = new Finch();
        int times, act, velocity, direc, dist;
        double beat;
        String direcS;
        int blank[] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
        int smile[] = {1,0,0,0,1,1,0,0,0,1,0,0,0,0,0,1,0,0,0,1,0,1,1,1,0};
        int dash[] = {1,0,0,0,1,0,1,0,1,0,1,0,0,0,1,1,0,0,0,1,0,1,1,1,0};
        int sing[] = {1,0,0,0,1,1,0,0,1,1,0,0,1,0,1,0,0,1,0,1,0,0,0,1,0};
        int sad[] = {1,0,0,0,1,1,0,0,0,1,0,0,0,0,0,0,1,1,1,0,1,0,0,0,1};
        myFinch.setDisplay(smile);
        //myFinch.playNote(60,0.5);
        myFinch.setTail(1, 0, 0, 0);
        myFinch.setTail(2, 0, 0, 0);
        myFinch.setTail(3, 0, 0, 0);
        myFinch.setTail(4, 0, 0, 0);
        try(Scanner input = new Scanner(System.in))
        {
            do{
                System.out.println("Which type of action do you want?");
                System.out.println("(1 for sqaure movement, 2 for free roam)");
                act = input.nextInt();
                
                if (act == 1){
                    System.out.println("Square it is!");
                    System.out.println("Now choose your speed!");
                    velocity = input.nextInt();
                    myFinch.setDisplay(dash);
                    for (times = 0; times < 4; times++){
                        myFinch.setMove("f", 15, velocity);
                        myFinch.setTurn("r", 90, velocity); 
                    }
                    myFinch.setDisplay(smile);
                }else if (act == 2){
                    System.out.println("Free roam!");
                    do{
                        System.out.println("Choose 1 to walk, 2 to turn, 3 for tail light, 4 for beak light, 5 for notes and -1 to exit");
                        act = input.nextInt();
                        if (act == 1){
                        System.out.println("Now choose your speed!");
                            velocity = input.nextInt();
                            System.out.println("Now choose your distance!");
                            dist = input.nextInt();
                            System.out.println("Now choose your direction!(1 for forward, 2 for back)");
                            direc = input.nextInt();
                            switch (direc)
                            {
                                case 1 -> direcS = "f";
                                case 2 -> direcS = "b";
                                default -> direcS = "f";
                            }
                            myFinch.setDisplay(dash);
                            myFinch.setMove(direcS, dist, velocity);
                            myFinch.setDisplay(smile); 
                        } else if (act == 2){
                            System.out.println("Now choose your speed!");
                            velocity = input.nextInt();
                            System.out.println("Now choose your angle!");
                            dist = input.nextInt();
                            System.out.println("Now choose your direction!(1 for right, 2 for left)");
                            direc = input.nextInt();
                            switch (direc)
                            {
                                case 1 -> direcS = "r";
                                case 2 -> direcS = "l";
                                default -> direcS = "r";
                            }
                            myFinch.setDisplay(dash);
                            myFinch.setTurn(direcS, dist, velocity);
                            myFinch.setDisplay(smile); 
                        } else if (act == 3){
                            System.out.println("Now choose your LED port(1-4)!");
                            if (act > 4 || act < 1)
                                act = 1;
                            act = input.nextInt();
                            System.out.println("Now choose your red!");
                            velocity = input.nextInt();
                            if (velocity > 100 || act < 0)
                                velocity = 0;
                            System.out.println("Now choose your green!");
                            dist = input.nextInt();
                            if (dist > 100 || dist < 0)
                                dist = 0;
                            System.out.println("Now choose your blue!");
                            direc = input.nextInt();
                            if (direc > 100 || direc < 0)
                                direc = 0;
                            myFinch.setTail(act, velocity, dist, direc);
                        } else if (act == 4){
                            System.out.println("Now choose your red!");
                            velocity = input.nextInt();
                            if (velocity > 100 || act < 0)
                                velocity = 0;
                            System.out.println("Now choose your green!");
                            dist = input.nextInt();
                            if (dist > 100 || dist < 0)
                                dist = 0;
                            System.out.println("Now choose your blue!");
                            direc = input.nextInt();
                            myFinch.setBeak(velocity, dist, direc);
                        } else if (act == 5) {
                            System.out.println("Now choose your midi note!(Goes through 32-135)");
                            velocity = input.nextInt();
                            if (velocity > 135 || velocity < 32){
                                velocity = 32;
                            }
                            System.out.println("Now choose a beat length(uses floating point)");
                            beat = input.nextDouble();
                            myFinch.setDisplay(sing);
                            myFinch.setMove("f",1,1);
                            myFinch.playNote(velocity, beat);
                            myFinch.setMove("f",1,1);
                            myFinch.setDisplay(smile);
                        }
                        if (act < 0)
                        {
                           myFinch.setDisplay(sad);
                           myFinch.setMove("f",1,1);
                           myFinch.setDisplay(smile);
                        }
                    } while (act >= 0);
                    act = 1;
                    myFinch.setTail(1, 0, 0, 0);
                    myFinch.setTail(2, 0, 0, 0);
                    myFinch.setTail(3, 0, 0, 0);
                    myFinch.setTail(4, 0, 0, 0);
                    myFinch.setBeak(0, 0, 0);
                } 
            } while (act >= 0);
            
        }  
        myFinch.stopAll();
        myFinch.disconnect();
    }
}

