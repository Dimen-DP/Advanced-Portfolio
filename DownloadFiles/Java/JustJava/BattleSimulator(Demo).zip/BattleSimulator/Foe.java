import java.util.Random;

public class Foe
{
    private int hp = 0;
    private int maxHp = 0;
    private int atk = 0;
    private int def = 0;
    private int definedDef = def;
    private int mp = 0;
    private int maxMp = 0;
    private String opName = "";
    private int enID = 0;
    private int mAtk = 0;
    private int mDef = 0;
    private int defMDef = mDef;
    private int spd = 0;
    private int defSpd = spd;
    private int pDef = 0;
    private int pMDef = 0;
    private double bluntWeak = 1;
    private double slashWeak = 1;
    private double piercWeak = 1;
    private double blazeWeak = 1;
    private double returnedWeakness = 1;
    private boolean slimeSlow = false;
    private int slimeSlowTimer = 0;
    Skill skillset = new Skill();
    Random random = new Random();
    private int rng = 0;

    public Foe(int arguement)
    {
        setEnemy(arguement);
    }
    public String showStats()
    {
        return "Name: " + opName + " ID: " + enID + " HP: " + hp + " Max HP: " + maxHp + " MP: " + mp + " max MP " + maxMp + " Attack: " + atk + " Magic Attack: " + mAtk + " Defense: " + def + " Magic Defense: " + mDef;
    }
    
    public void clearStats()
    {
        hp = 0;
        maxHp = 0;
        atk = 0;
        def = 0;
        mp = 0;
        maxMp = 0;
        opName = "";
        enID = 0;
        mAtk = 0;
        mDef = 0;
        bluntWeak = 1;
        slashWeak = 1;
        piercWeak = 1;
        blazeWeak = 1;
    }

    public void setEnemy(int index)
    {
        switch (index)
        {
            case 1 -> enID = 1;
            case 2 -> enID = 2;
        }
        if (enID == 1)
        {
            maxHp = 240;
            hp = maxHp;
            maxMp = 20;
            mp = maxMp;
            opName = "Slime";
            atk = 35;
            mAtk = 10;
            def = 10;
            mDef = 20;
            spd = 15;
            bluntWeak = 0.5;
            slashWeak = 1.5;
            piercWeak = 1;
            blazeWeak = 0;
        }
        if (enID == 2)
        {
            maxHp = 180;
            hp = maxHp;
            maxMp = 10;
            mp = maxMp;
            opName = "Goblin";
            atk = 25;
            mAtk = 0;
            def = 20;
            mDef = 20;
            spd = 18;
            bluntWeak = 1;
            slashWeak = 1;
            piercWeak = 1;
            blazeWeak = 1.5;
        }
    }

    public void takeDamage(double amount)
    {
        hp -= amount;
    }

    public void healDamage(int amount)
    {
        hp += amount;
        if (hp > maxHp)
        {
            hp = maxHp;
        }
    }

    public double dealDamage(int arguement)
    {
        return skillset.library(arguement, atk, mAtk, pDef, pMDef, opName, 2, "Pureiya");
    }

    public boolean ailmentEffect()
    {
        return skillset.ailmentEffect();
    }

    public int ailmentTypeShow()
    {
        return skillset.ailmentTypeShow();
    }

    public void getPlayerDefense(int playerDefense, int playerMagicDefense)
    {
        pDef = playerDefense;
        pMDef = playerMagicDefense;
        //System.out.println("I " + opName + " accept this!");
    }

    public int giveDefense()
    {
        return definedDef;
    }

    public int giveMagicDefense()
    {
        return defMDef;
    }

    public int showHp()
    {
        return hp;
    }

    public double giveWeak(int index)
    {
        switch (index)
        {
            case 1 -> returnedWeakness = bluntWeak;
            case 2 -> returnedWeakness = slashWeak;
            case 3 -> returnedWeakness = piercWeak;
            case 4 -> returnedWeakness = blazeWeak;
        }
        //if (returnedWeakness < 1)
        //    System.out.println("Resisted Damage");
        return returnedWeakness;
    }

    public String getName()
    {
        return opName;
    }

    public int giveSpeed()
    {
        return defSpd;
    }

    public Double enemyTurn()
    {
        double dam = 0;
        System.out.println(opName + "'s turn: ");
        System.out.println(opName + " health: " + hp + "/" + maxHp);
        System.out.println(opName + " MP: " + mp + "/" + maxMp);
        dam = enemyAI();
        return dam;
    }
    
    public void giveEffect(int arguement)
    {
        switch (arguement)
        {
            case 1 -> {slimeSlow = true;
                slimeSlowTimer = 3;
            }
        }
    }

    public void refreshStats(int arguement)
    {
        //0 will equal buff/debuff timer not going down, 1 it will go down
        if (arguement == 1)
        {
            slimeSlowTimer --;
            if (slimeSlowTimer <= 0)
            {
                System.out.println("The slime slided off");
                slimeSlow = false;
            }
        }
        defSpd = spd;
        definedDef = def;
        defMDef = mDef;
        //defense changes
        if (slimeSlow == true)
        {
            definedDef *= 0.9;
            defMDef *= 0.9;
        }
        //speed changes
        if (slimeSlow == true)
            defSpd -= 6;
    }

    public double enemyAI()
    {
        double dam = 0;
        switch (enID)
        {
           case 1 -> dam = slimeAi();
           case 2 -> dam = dealDamage(1);
        }
        return dam;
    }

    public double slimeAi()
    {
        rng = random.nextInt(1, 3);
        double dam = 0;
        switch (rng)
        {
           case 1 -> dam = dealDamage(1);
           case 2 -> {
            if (mp >= 5) {
                dam = skillset.library(7, atk, mAtk, pDef, pMDef, opName, 2, "Pureiya");
                mp -= 5;
                }else {
                    System.out.println("Slime ran out of MP");  
                }
            }
        }
        return dam;
    }
}