import java.util.Scanner;

public class Player
{ 
    private int maxHp = 120;
    private int hp = maxHp;
    private int atk = 30;
    private int def = 15;
    private int definedDef = def;
    private int maxMp = 60;
    private int mp = maxMp;
    private String name = "Pureiya";
    private int mAtk = 30;
    private int mDef = 15;
    private int defMDef = mDef;
    private int eDef = 0;
    private int eMDef = 0;
    private int spd = 20;
    private int defSpd = spd;
    private double bluntWeak = 1;
    private double slashWeak = 1;
    private double piercWeak = 1;
    private double blazeWeak = 1;
    private String opName;
    private double returnedWeakness = 1;
    private boolean slimeSlow = false;
    private int slimeSlowTimer = 0;
    Scanner input = new Scanner(System.in);
    Skill skillset = new Skill();

    public String showStats()
    {
        return "Name: " + name +  " HP: " + hp + " Max HP: " + maxHp + " MP: " + mp + " max MP " + maxMp + " Attack: " + atk + " Magic Attack: " + mAtk + " Defense: " + def + " Magic Defense: " + mDef;
    }


    public void takeDamage(double amount)
    {
        hp -= amount;
    }

    public void healDamage(int amount)
    {
        hp += amount;
        if (hp > maxHp)
        {
            hp = maxHp;
        }
    }

    public double dealDamage()
    {
        return skillset.library(2, atk, mAtk, eDef, eMDef, name, 1, opName);
    }

    public int giveDefense()
    {
        return definedDef;
    }

    public int giveMagicDefense()
    {
        return defMDef;
    }

    public int showHp()
    {
        return hp;
    }

    public void getEnemyDefense(int enemyDefense, int enemyMagicDefense)
    {
        eDef = enemyDefense;
        eMDef = enemyMagicDefense;
    }

    public double giveWeak(int index)
    {
        switch (index)
        {
            case 1 -> returnedWeakness = bluntWeak;
            case 2 -> returnedWeakness = slashWeak;
            case 3 -> returnedWeakness = piercWeak;
            case 4 -> returnedWeakness = blazeWeak;
        }
        return returnedWeakness;
    }

    public double SkillMenu()
    {
        int choose = 0;
        double dam = 1.0;
        System.out.println("Choose a skill");
        System.out.println("1. Flashing Pierce 8 MP");
        System.out.println("2. Triple Slash 10 MP");
        System.out.println("3. Weakness Target 15 MP");
        System.out.println("-1. Return back");
        choose = input.nextInt();
        switch (choose)
        {
            case 1 -> {
                if (mp >= 8) {
                    dam = skillset.library(4, atk, mAtk, eDef, eMDef, name, 1,opName);
                    mp -= 8;
                } else {
                    System.out.println("Not enough MP");
                    dam = -1;
                }   
            }
            case 2 -> {
                if (mp >= 10) {
                    dam = skillset.library(5, atk, mAtk, eDef, eMDef, name, 1,opName);
                    mp -= 10;
                } else {
                    System.out.println("Not enough MP");
                    dam = -1;    
                }
                }
            case 3 -> {
                if (mp >= 15) {
                    dam = skillset.library(6, atk, mAtk, eDef, eMDef, name, 1,opName);
                    mp -= 15;
                } else {
                    System.out.println("Not enough MP");
                    dam = -1;    
                }
            }
            default ->{
                dam = -1;
                System.out.println("You must input a valid choice!"); 
            } 
        }
        return dam;
    }

    public double playerTurn()
    {
        double uniDamage = 90.0;
        do{
            //Player turn
            System.out.println("Pureiya's turn: ");
            System.out.println("Pureiya health: " + hp + "/" + maxHp);
            System.out.println("Pureiya MP: " + mp + "/" + maxMp);
            System.out.println("1. Basic Attack");
            System.out.println("2. Skill Menu");
            System.out.println("3. Magic Menu");
            int choice = input.nextInt();
            
                switch (choice)
                {
                    case 1 -> {
                        uniDamage = dealDamage();
                    }
                    case 2 -> {
                        uniDamage = SkillMenu();
                    }
                    case 3 -> {
                        uniDamage = magicMenu();
                    }
                    default -> {
                        uniDamage = -1;
                    }
                }
            } while (uniDamage == -1);
        return uniDamage;
    }

    public int giveSpeed()
    {
        return defSpd;
    }

    public void getEnemy(String arguement)
    {
        opName = arguement;
    }

    public void giveEffect(int arguement)
    {
        switch (arguement)
        {
            case 1 -> {slimeSlow = true;
                slimeSlowTimer = 3;
            }
        }
    }

    public void refreshStats(int arguement)
    {
        //0 will equal buff/debuff timer not going down, 1 it will go down
        if (arguement == 1)
        {
            slimeSlowTimer --;
            if (slimeSlowTimer <= 0)
            {
                System.out.println("The slime slided off");
                slimeSlow = false;
            }
        }
        defSpd = spd;
        definedDef = def;
        defMDef = mDef;
        //defense changes
        if (slimeSlow == true)
        {
            definedDef *= 0.9;
            defMDef *= 0.9;
        }
        //speed changes
        if (slimeSlow == true)
            defSpd -= 6;
    }

    public double magicMenu()
    {
        int choose = 0;
        double dam = 1.0;
        System.out.println("Choose a skill");
        System.out.println("1. FireBall 8 MP");
        System.out.println("-1. Return back");
        choose = input.nextInt();
        switch (choose)
        {
            case 1 -> {
                if (mp >= 8) {
                    dam = skillset.library(8, atk, mAtk, eDef, eMDef, name, 1,opName);
                    mp -= 8;
                } else {
                    System.out.println("Not enough MP");
                    dam = -1;
                }   
            }
            default ->{
                dam = -1;
                System.out.println("You must input a valid choice!"); 
            } 
        }
        return dam;
    }
}