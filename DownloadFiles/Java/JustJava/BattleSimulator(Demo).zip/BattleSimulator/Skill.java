import java.util.Random;

public class Skill {
    private int element = 0, ailmentType, rng, ailmentChance;
    private boolean ailment;
    Random random = new Random();
    public double library(int index, int attack, int magicAtk, int defense, int magicDef, String name, int target, String TargetName)
    {
        double calc = 0;
        double multAtk = 0;
        ailment = false;
        ailmentType = 0;
        switch (index)
        {
            case 1:
                element = 1; //blunt element
                System.out.printf("%s used Basic Blunt Attack \n", name, target);
                calc = DamageCalc.calcPhys(attack,defense,1,16,1.5,element, target);
                ailment = false;
                break;
            case 2:
                element = 2; //slash element
                System.out.printf("%s used Basic Slash Attack \n", name, target);
                calc = DamageCalc.calcPhys(attack,defense,1,16,1.5, element, target);
                ailment = false;
                break;
            case 3:
                element = 3;//pierce element
                System.out.printf("%s used Basic Pierce Attack \n", name, target);
                calc = DamageCalc.calcPhys(attack,defense,1,16,1.5, element, target);
                ailment = false;
                break;
            case 4:
                element = 3;//pierce element
                System.out.printf("%s used Flashing Pierce \n", name, target);
                calc = DamageCalc.calcPhys((attack * 1.5),defense,1,16,1.5, element, target);
                ailment = false;
                break;
            case 5:
                element = 2; //slash element
                System.out.printf("%s used Triple Slash \n", name, target);
                calc = 0;
                for (int x = 0; x < 3; x++)
                {
                   multAtk = DamageCalc.calcPhys(attack,defense,1,16,1.5, element, target);
                   System.out.println(multAtk + " Damage was dealt!");
                   calc += multAtk;                
                }
                ailment = false;
                break;
            case 6:
                element = 1; //blunt element
                System.out.printf("%s used Weakness Target \n", name, target);
                calc = DamageCalc.calcPhys(attack,defense,1,1,2,element, target);
                ailment = false;
                break;
            case 7:
                element = 1; //blunt element
                System.out.printf("%s used Slime Sludge \n", name, target);
                calc = DamageCalc.calcPhys((attack*0.8),defense,1,16,3,element, target);
                ailmentChance = 4;
                rng = random.nextInt(1, ailmentChance + 1);
                if (rng == ailmentChance)
                {
                    ailment = true;
                    ailmentType = 1;
                }
                else
                    ailment = false;
                break;
            case 8:
                element = 4;//fire element
                System.out.printf("%s used Fireball \n", name, target);
                calc = DamageCalc.calcMag(attack, defense, 1, 16, 1.5, element, target, 8);
                ailment = false;
                break;
        }
        System.out.println(name + " dealt " + calc + " damage!");
        return calc;
    }
    
    public int getElement()
    {
        //obselete
        return element;
    }

    public boolean ailmentEffect()
    {
        return ailment;
    }

    public int ailmentTypeShow()
    {
        return ailmentType;
    }
}