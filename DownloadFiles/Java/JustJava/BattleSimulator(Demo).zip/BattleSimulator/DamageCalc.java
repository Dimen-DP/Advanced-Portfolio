import java.util.Random;

public class DamageCalc {

    private static double enemyWeakBlunt = 1;
    private static double enemyWeakSlash = 1;
    private static double enemyWeakPierc = 1;
    private static double enemyWeakBlaze = 1;
    public static double calcPhys(double attack, int defense, int division, int crit, double critDmg, int elPointer, int target)
    {
        //target 1 = foe, 2 = player
        Random random = new Random();
        double ceil = random.nextDouble(80,101) / 100.0;
        double rng = random.nextInt(1, crit + 1);
        boolean critY = false;
        double weaknessMult = 1;
        if (rng == crit)
        {
            ceil = 1;
            critY = true;
        }
        double damage = (ceil * attack) - defense;
        if (division != 1)
            damage /= division;
        if (critY == true)
        {
            System.out.println("CRITICAL HIT!");
            damage *= critDmg;
        }
        if (target == 2)
        {
            weaknessMult = 1;
        }
        else if (target == 1)
        {
            weaknessMult = weakCalc(elPointer);
        }
        weakText(weaknessMult);
        damage *= weaknessMult;
        if (damage < 0)
            damage = 0;
        return damage;
    }

    public static double calcMag(double attack, int defense, int division, int crit, double critDmg, int elPointer, int target, int magicPow)
    {
        //target 1 = foe, 2 = player
        Random random = new Random();
        double ceil = random.nextDouble(80,101) / 100.0;
        double rng = random.nextInt(1, crit + 1);
        boolean critY = false;
        double weaknessMult = 1;
        if (rng == crit)
        {
            ceil = 1;
            critY = true;
        }
        double damage = (ceil * attack + magicPow) - defense;
        if (division != 1)
            damage /= division;
        if (critY == true)
        {
            System.out.println("CRITICAL HIT!");
            damage *= critDmg;
        }
        if (target == 2)
        {
            weaknessMult = 1;
        }
        else if (target == 1)
        {
            weaknessMult = weakCalc(elPointer);
        }
        weakText(weaknessMult);
        damage *= weaknessMult;
        if (damage < 0)
            damage = 0;
        return damage;
    }

    public static void getFoe(int arguement)
    {
        Foe fWeak = new Foe(arguement);
        enemyWeakBlunt = fWeak.giveWeak(1);
        enemyWeakSlash = fWeak.giveWeak(2);
        enemyWeakPierc = fWeak.giveWeak(3);
        enemyWeakBlaze = fWeak.giveWeak(4);
    }

    public static void weakText(double weaknessMult)
    {
        if (weaknessMult == 0)
            System.out.println("Immune...");
        else if (weaknessMult > 1)
            System.out.println("Weak!");
        else if (weaknessMult < 1)
            System.out.println("Resist...");
    }

    public static double weakCalc(int elPointer)
    {
        double weakness = 0;
        switch(elPointer)
            {
                case 1 -> weakness = enemyWeakBlunt;
                case 2 -> weakness = enemyWeakSlash;
                case 3 -> weakness = enemyWeakPierc;
                case 4 -> weakness = enemyWeakBlaze;
            }
        return weakness;
    }
}