#rpg.java(Battle Simulator)

#Reason
To test how I've grown and show my Java skills.

#Features
- RNG that works for primitive AI
- Working element system with weaknesses
- Working ailment system
- Multi Hit moves
 
#Limitations
Error will run if you use a non-int(string, extra characters or decimal) when the game asks for an int input. 

#Download
You need java downloaded, best to use the newest version of java.
either you can use VSCode since this is source code, or you can turn them into class files to run them in command prompt.

#How to run
either use an interpreter of your choice or use 

#story
Player(Pu-Rei-Ya) MC(N-Shi) is a girl in a small village. 
She is the daughter of NPC(N-Pi-Shi) MC and CPU(Shi-Pi-Yu) MC.
Player decided to go outside her village and see the world.
But she needed equipment for that so she asked her father to make armor and a sword for her, which he obliged. 
But she on her journey. She found a witch who would give her a magic item in return for helping her.
As the good person Player is she helped the which.
But instead she was cursed by a witch which put her in a time loop. 
Where she would have to endlessly fight enemies in the end if she dies she loops if she triumphs she loops. 
But it wasn't really a 'timeloop' it was a pocket dimension made by the witch which allowed her to control everything inside.
The pocket dimension was a perfect replica of their world even to the parts the witch didn't know existed.
Of course the witch isn't cruel so she have player the abilities needed to beat her foes.
She gave player multiple spells that would keep her weak but could make her strong enough to beat her foes.
Even having DevTools which are cosmic authorities that change the world around her.

If there's any issues you want to tell me about just email me. Which is in the footer of my website.