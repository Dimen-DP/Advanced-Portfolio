import java.util.Scanner;
import java.util.Random;

public class rpg {
    //this is a placeholder for the future
    //java auto rounds up when doing hp - damage
    public static void main(String[] args)
    {
        //Object Creation Stage
        Random random = new Random();
        int enemyIndex = random.nextInt(1,2);
        Foe enemy = new Foe(enemyIndex);
        DamageCalc.getFoe(enemyIndex);
        Scanner input = new Scanner(System.in);
        Player pureiya = new Player();
        double uniDamage;
        Skill skillset = new Skill();
        //Integer Creation
        //int foeHealth;
        int pSpd, eSpd, rng = 0, turn = 1;
        String enemyName = enemy.getName();
        boolean enTurn = true, pTurn = true;
        //int weakness;
        //int choice = 0;
        //boolean didAtk = false;
        
        //Testing below
        //System.out.println(enemy.showStats());
        //enemy.clearStats();
        //System.out.println(enemy.showStats());
        //enemy.setEnemy(1);
        //System.out.println(enemy.showStats());
        //enemy.takeDamage(20);
        //System.out.println(enemy.showStats());
        //enemy.healDamage(999);
        //System.out.println(enemy.showStats());
        
        //enemy.dealDamage();
        //weakness = skillset.getElement();
        //System.out.println(weakness);
        //System.out.println(enemy.giveWeak(weakness));
        System.out.println("Turn 1 start!");
        do{
            //Turn Start
            evalStats(pureiya, enemy, 0, 0);
            pSpd = pureiya.giveSpeed();
            eSpd = enemy.giveSpeed();
            if (pTurn == false)
                pSpd = 0;
            if (enTurn == false)
                eSpd = 0;
            if (pSpd == eSpd && pTurn == true && enTurn == true)
                rng = random.nextInt(0,2);
                if (rng == 0)
                    pSpd -= 1;
                else
                    pSpd += 1;

            if (pSpd > eSpd && pTurn == true)
            {
                //Player turn
                evalStats(pureiya, enemy, 0, 1);
                uniDamage = pureiya.playerTurn();
                //weakness = skillset.getElement();
                enemy.takeDamage(uniDamage);
                ailmentSet(skillset, 1, pureiya, enemy, enemyName);
                pTurn = false;
                if (enemy.showHp() <= 0)
                {
                    System.out.println("Pureiya wins!");
                    break; 
                }
                     
            }
            if (eSpd > pSpd && enTurn == true)
            {
                //enemy turn
                evalStats(pureiya, enemy, 1, 0);
                uniDamage = enemy.enemyTurn();
                //weakness = skillset.getElement();
                pureiya.takeDamage(uniDamage);
                ailmentSet(skillset, 0, pureiya, enemy, enemyName);
                enTurn = false;
            }
            if (pTurn == false && enTurn == false)
            {
                turn ++;
                System.out.println("Turn " + turn + " start!");
                pTurn = true;
                enTurn = true;
            }
        } while (pureiya.showHp() > 0 && enemy.showHp() > 0);
            if (pureiya.showHp() <= 0)
                System.out.println(enemyName + " wins!");
        input.close();
    }

    public static void evalStats(Player pureiya, Foe enemy, int tickEn, int tickP)
    {
        int transferDefense = 0;
        int transferMagicDefense = 0;
        enemy.refreshStats(tickEn);
        pureiya.refreshStats(tickP);
        transferDefense = pureiya.giveDefense();
        transferMagicDefense = pureiya.giveMagicDefense();
        enemy.getPlayerDefense(transferDefense, transferMagicDefense);
        transferDefense = enemy.giveDefense();
        transferMagicDefense = enemy.giveMagicDefense();
        pureiya.getEnemyDefense(transferDefense, transferMagicDefense);
    }
    
    public static void ailmentSet(Skill skillset, int arguement, Player pureiya, Foe enemy, String enemyName)
    {
        //0 = player, 1 = Foe
        if (arguement == 0)
        {
            if (skillset.ailmentEffect() == true)
            {
                    switch (skillset.ailmentTypeShow()) {
                        case 1 -> System.out.println("Pureiya is dragged down by slime");
                    }
                    pureiya.giveEffect(skillset.ailmentTypeShow());
            }
        }
        
        if (arguement == 1)
        {
            if (skillset.ailmentEffect() == true)
            {
                    switch (skillset.ailmentTypeShow()) {
                        case 1 -> System.out.println(enemyName + " is dragged down by slime");
                    }
                    enemy.giveEffect(skillset.ailmentTypeShow());
            }
        }
    }
}